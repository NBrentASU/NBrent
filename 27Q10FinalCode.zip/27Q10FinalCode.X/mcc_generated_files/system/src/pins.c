/**
 * Generated Driver File
 * 
 * @file pins.c
 * 
 * @ingroup  pinsdriver
 * 
 * @brief This is generated driver implementation for pins. 
 *        This file provides implementations for pin APIs for all pins selected in the GUI.
 *
 * @version Driver Version 3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#include "../pins.h"

void (*IO_RA1_InterruptHandler)(void);
void (*IO_RA6_InterruptHandler)(void);
void (*IO_RC0_InterruptHandler)(void);
void (*IO_RC1_InterruptHandler)(void);
void (*IO_RC2_InterruptHandler)(void);

void PIN_MANAGER_Initialize(void)
{
   /**
    LATx registers
    */
    LATA = 0x0;
    LATB = 0x0;
    LATC = 0x0;
    /**
    ODx registers
    */
    ODCONA = 0x40;
    ODCONB = 0x0;
    ODCONC = 0x7;

    /**
    TRISx registers
    */
    TRISA = 0xC3;
    TRISB = 0xFB;
    TRISC = 0xB7;

    /**
    ANSELx registers
    */
    ANSELA = 0x81;
    ANSELB = 0xF9;
    ANSELC = 0x90;

    /**
    WPUx registers
    */
    WPUA = 0x2;
    WPUB = 0x0;
    WPUC = 0x0;
    WPUE = 0x0;


    /**
    SLRCONx registers
    */
    SLRCONA = 0xFF;
    SLRCONB = 0xFF;
    SLRCONC = 0xFF;

    /**
    INLVLx registers
    */
    INLVLA = 0xFF;
    INLVLB = 0xFF;
    INLVLC = 0xFF;
    INLVLE = 0x8;

   /**
    RxyI2C | RxyFEAT registers   
    */
    /**
    PPS registers
    */
    SSP1DATPPS = 0x9; //RB1->MSSP1:SDI1;
    RX1PPS = 0x15; //RC5->EUSART1:RX1;
    RC6PPS = 0x09;  //RC6->EUSART1:TX1;

   /**
    IOCx registers 
    */
    IOCAP = 0x40;
    IOCAN = 0x2;
    IOCAF = 0x0;
    IOCBP = 0x0;
    IOCBN = 0x0;
    IOCBF = 0x0;
    IOCCP = 0x7;
    IOCCN = 0x0;
    IOCCF = 0x0;
    IOCEP = 0x0;
    IOCEN = 0x0;
    IOCEF = 0x0;

    IO_RA1_SetInterruptHandler(IO_RA1_DefaultInterruptHandler);
    IO_RA6_SetInterruptHandler(IO_RA6_DefaultInterruptHandler);
    IO_RC0_SetInterruptHandler(IO_RC0_DefaultInterruptHandler);
    IO_RC1_SetInterruptHandler(IO_RC1_DefaultInterruptHandler);
    IO_RC2_SetInterruptHandler(IO_RC2_DefaultInterruptHandler);

    // Enable PIE0bits.IOCIE interrupt 
    PIE0bits.IOCIE = 1; 
}
  
void PIN_MANAGER_IOC(void)
{
    // interrupt on change for pin IO_RA1
    if(IOCAFbits.IOCAF1 == 1)
    {
        IO_RA1_ISR();  
    }
    // interrupt on change for pin IO_RA6
    if(IOCAFbits.IOCAF6 == 1)
    {
        IO_RA6_ISR();  
    }
    // interrupt on change for pin IO_RC0
    if(IOCCFbits.IOCCF0 == 1)
    {
        IO_RC0_ISR();  
    }
    // interrupt on change for pin IO_RC1
    if(IOCCFbits.IOCCF1 == 1)
    {
        IO_RC1_ISR();  
    }
    // interrupt on change for pin IO_RC2
    if(IOCCFbits.IOCCF2 == 1)
    {
        IO_RC2_ISR();  
    }
}
   
/**
   IO_RA1 Interrupt Service Routine
*/
void IO_RA1_ISR(void) {

    // Add custom IO_RA1 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RA1_InterruptHandler)
    {
        IO_RA1_InterruptHandler();
    }
    IOCAFbits.IOCAF1 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RA1 at application runtime
*/
void IO_RA1_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RA1_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RA1
*/
void IO_RA1_DefaultInterruptHandler(void){
    // add your IO_RA1 interrupt custom code
    // or set custom function using IO_RA1_SetInterruptHandler()
}
   
/**
   IO_RA6 Interrupt Service Routine
*/
void IO_RA6_ISR(void) {

    // Add custom IO_RA6 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RA6_InterruptHandler)
    {
        IO_RA6_InterruptHandler();
    }
    IOCAFbits.IOCAF6 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RA6 at application runtime
*/
void IO_RA6_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RA6_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RA6
*/
void IO_RA6_DefaultInterruptHandler(void){
    // add your IO_RA6 interrupt custom code
    // or set custom function using IO_RA6_SetInterruptHandler()
}
   
/**
   IO_RC0 Interrupt Service Routine
*/
void IO_RC0_ISR(void) {

    // Add custom IO_RC0 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RC0_InterruptHandler)
    {
        IO_RC0_InterruptHandler();
    }
    IOCCFbits.IOCCF0 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RC0 at application runtime
*/
void IO_RC0_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RC0_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RC0
*/
void IO_RC0_DefaultInterruptHandler(void){
    // add your IO_RC0 interrupt custom code
    // or set custom function using IO_RC0_SetInterruptHandler()
}
   
/**
   IO_RC1 Interrupt Service Routine
*/
void IO_RC1_ISR(void) {

    // Add custom IO_RC1 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RC1_InterruptHandler)
    {
        IO_RC1_InterruptHandler();
    }
    IOCCFbits.IOCCF1 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RC1 at application runtime
*/
void IO_RC1_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RC1_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RC1
*/
void IO_RC1_DefaultInterruptHandler(void){
    // add your IO_RC1 interrupt custom code
    // or set custom function using IO_RC1_SetInterruptHandler()
}
   
/**
   IO_RC2 Interrupt Service Routine
*/
void IO_RC2_ISR(void) {

    // Add custom IO_RC2 code

    // Call the interrupt handler for the callback registered at runtime
    if(IO_RC2_InterruptHandler)
    {
        IO_RC2_InterruptHandler();
    }
    IOCCFbits.IOCCF2 = 0;
}

/**
  Allows selecting an interrupt handler for IO_RC2 at application runtime
*/
void IO_RC2_SetInterruptHandler(void (* InterruptHandler)(void)){
    IO_RC2_InterruptHandler = InterruptHandler;
}

/**
  Default interrupt handler for IO_RC2
*/
void IO_RC2_DefaultInterruptHandler(void){
    // add your IO_RC2 interrupt custom code
    // or set custom function using IO_RC2_SetInterruptHandler()
}
/**
 End of File
*/