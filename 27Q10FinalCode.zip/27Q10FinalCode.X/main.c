#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/uart/eusart1.h"
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>

//Create fan turn on with on board button to toggle on and off
int errNum;
 
uint8_t buffer[2];
uint8_t incoming;
uint8_t msg_ii;
uint8_t msg[65];
uint8_t i;
uint8_t last_i;
uint8_t msg_complete;
uint8_t start1 = 0x41;
uint8_t start2 = 0x5A;
uint8_t end1 = 0x59;
uint8_t end2 = 0x42;


#define C1F 0x30 //For forward first byte transmission (OUT1 High, OUT2 Low, reset off)
#define C1R 0x48 //For reverse first byte transmission (OUT2 High, OUT1 Low, reset off)
#define SPICap 0x07 //For 2nd byte transmission (Warnings all enabled)
#define driverOff 0x00 //For turning off OUTs
#define dummy 0x00 //Needed for some reason #structuralCoconut


uint8_t bufferCommandOne[2];
uint8_t bufferCommandTwo[2];
uint8_t bufferOff[2];
uint8_t bufferMessage[2];
int speedInt = 1;
int fanMode = 0; //0 Off 1 On
int f = 0; //for fan code to make sure doesnt do both ifs
    

void sensorOne(){ 
    
    //Triggers Sens 1, Turns off magnet, Triggers sens 3, delay, Turn on coil Two
    
    IO_RA3_SetHigh();
    IO_RA2_SetLow();
    
    IO_RC3_SetLow();

   /* IO_RA4_SetLow();
    
    SPI1_BufferWrite(bufferOff, 2);
    SPI1_ByteWrite(dummy);
    
    IO_RA4_SetHigh();
    
    __delay_ms(1);
    
    SPI1_BufferRead(bufferMessage, 2);
    //printf("AZNES1YB");
    * */
}

void sensorTwo(){
    //if RA6 (sensThree) High, enable coil 2
    IO_RA3_SetLow();
    IO_RA2_SetHigh();
    
    IO_RC3_SetHigh();

    
   /* __delay_ms(250); //Delay to turn on coil
    
    IO_RA4_SetLow();
    
    SPI1_BufferWrite(bufferCommandOne, 2);
    SPI1_ByteWrite(dummy);
    
    __delay_ms(100);
    
    IO_RA4_SetHigh();
    __delay_ms(1);
    
    SPI1_BufferRead(bufferMessage, 2);
    //printf("AZNE2YB");
    */
}

void sensorThree(){ 
    //Conditional if statement checking it sensor has been triggered yet to begin movement?
    //Triggers Sens 4, Turns off magnet, Triggers sens 2, delay, Turn on coil One
    
    IO_RA3_SetHigh();
    
    IO_RB2_SetHigh();

    /*IO_RA2_SetHigh();
    
    __delay_ms(250); //Delay to turn on coil
    
    IO_RA5_SetLow();
    
    SPI1_BufferWrite(bufferCommandOne, 2);
    SPI1_ByteWrite(dummy);
    
    IO_RA5_SetHigh();
    
    SPI1_BufferRead(bufferMessage, 2);
    __delay_ms(1);
    
    //printf("AZNE3YB");
    */
}

void sensorFour(){
    
    IO_RA3_SetLow();

    IO_RA2_SetLow();
    
    IO_RB2_SetLow();
    
    /*IO_RA5_SetLow();
    
    SPI1_BufferWrite(bufferOff, 2);
    SPI1_ByteWrite(dummy);
    
    IO_RA5_SetHigh();
    
    SPI1_BufferRead(bufferMessage, 2);
    __delay_ms(1);
     
    //printf("AZNE4YB");
      */
}


void receiverFunc(){    
    //printf("interrupt");
    if (EUSART1_IsRxReady() == 1) {
        buffer[i] = EUSART1_Read();

        if (buffer[last_i] == start1 && buffer[i] == start2) {
            incoming = 1;
            msg[0] = buffer[last_i];
            msg_ii = 1;
            //IO_RD1_SetHigh();
        } else if (buffer[last_i] == end1 && buffer[i] == end2) {
            incoming = 0;
            msg[msg_ii-1] = buffer[last_i];
            msg[msg_ii] = buffer[i];
            msg_complete = 1;
            
            //IO_RD1_SetLow();
        } else if (msg_ii >= 64) {
            errNum = 1; 
        }

        if (incoming == 1) {
            msg[msg_ii] = buffer[i];
            msg_ii++;
        }

        last_i = i;
        i++;
        if (i >=2) {
            i = 0;
        }
    }   
}

void errorSend(){ //Checks error type and transmits
    
    //printf("Error: ");
    if(errNum == 1){ //Overflow error
        printf("AZNXF1YB");//Error 1 sent to MQTT
    }
    
    if(errNum == 2){ //Incorrect start byte
        printf("AZNXF2YB");//Error 2 sent to MQTT
    }
    
    if(errNum == 3){ //Incorrect Sender Address
        printf("AZNXF3YB");//Error 3 sent to MQTT
    }
    
    if(errNum == 4){ //Incorrect Receiver Address
        printf("AZNXF4YB");//Error 4 sent to MQTT
    }
    
    if(errNum == 5){ //Incorrect Message/ Data Type
        printf("AZNXF5YB");//Error 5 sent to MQTT
    }
    
    errNum = 0;
}

void actuatorFunctions(){
    //TBD, add if message type is good
    if(msg[4] == 0x53){ //Change to what Hunter sends me for speed
    //printf("Valid message for me");
        
        if(msg[5] == 1){ //Speed setting 1
        IO_RA2_SetHigh();
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        speedInt = 1;
        
        //Create speed setting variable eventually and integrate it into the break out loops
        
        } else if(msg[5] == 2){ //Speed setting 2
        IO_RA2_SetHigh();
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        IO_RA2_SetHigh();
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        speedInt = 2;
        
        } else if(msg[5] == 3){ //Speed setting 3
        IO_RA2_SetHigh();
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        IO_RA2_SetHigh(); 
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        IO_RA2_SetHigh();
        __delay_ms(250);
        IO_RA2_SetLow();
        __delay_ms(250);
        
        speedInt = 3;

        }else{
            errNum = 5;
        }

    }else{
        errNum = 5;
        errorSend(); //Invalid message
    }
}

void transmitMessage(){ //For transmitting messages
    
    if(msg[3] != 0x58 && msg[3] != 0x4e){ //If not for me
        //printf("Retransmit");
        printf("%s", msg); //Retransmit
    }else if(msg[3] == 0x58){ //After rebroadcast, use in my subsystem
        //printf("Broadcast");
        printf("%s", msg);
        
        if(msg[4] == 0x52){ //Master Reset
            //For verification
            IO_RA2_SetHigh();
            IO_RA3_SetHigh();
            __delay_ms(1000);
            IO_RA2_SetLow();
            IO_RA3_SetLow();
            
            //__asm__("reset");
        }
    }
}

void messageCompliance(){ //Checks if message is mine and if valid
    //Checking for all issues
    if(msg[0] == start1 && msg[1] == start2){ //Correct Start Byte
        
        if(msg[2] == 0x4b || msg[2] == 0x45 || msg[2] == 0x48){ //Correct Sender Address
            
            if(msg[3] == 0x4e){ //For me
                actuatorFunctions(); //Act on message
            }else if(msg[3] == 0x58){ //Broadcast address
                transmitMessage();
                //Then will go to actuator function
            } else if(msg[3] == 0x4b || msg[3] == 0x45 || msg[3] == 0x48 || msg[3] == 0x44){
                transmitMessage(); //Message not for me, retransmit
            } else {
                errNum = 4;
                errorSend(); //Not valid receiver address error
            }
            
        } else if(msg[2] == 0x4e){ //Trash message if receiving my own message
           // break; // will reinitalize loop and recreate char array "erasing" message
        } else { 
            errNum = 3;
            errorSend(); //Incorrect Sender Address
        }
        
    } else {
        errNum = 2;
        errorSend(); //Incomplete/Incorrect Start Byte
    }
}

int main(void)
{
    SYSTEM_Initialize();
    EUSART1_Initialize();
    SPI1_Initialize();
    INTERRUPT_Initialize();
    
    EUSART1_Enable();
    EUSART1_TransmitEnable();
    EUSART1_ReceiveEnable();
    EUSART1_ReceiveInterruptEnable();
    SPI1_Open(HOST_CONFIG);

    // Enable the Global Interrupts 
    //INTERRUPT_GlobalInterruptEnable(); 
    INTERRUPT_GlobalInterruptHighEnable();
    INTERRUPT_GlobalInterruptLowEnable();

    // Enable the Peripheral Interrupts 
    INTERRUPT_PeripheralInterruptEnable(); 
    
    EUSART1_RxCompleteCallbackRegister(receiverFunc);
    
    //IO_RA1_SetInterruptHandler(directionSwitch);
    //IO_RA1_SetInterruptHandler(fanToggle);
    IO_RA6_SetInterruptHandler(sensorThree); // Sens 3
    IO_RC2_SetInterruptHandler(sensorFour); // Sens 4
    IO_RC0_SetInterruptHandler(sensorTwo); // Sens 2
    IO_RC1_SetInterruptHandler(sensorOne); // Sens 1
    
    
    //Coil 1 On
    bufferCommandOne[0] = C1F;
    bufferCommandOne[1] = SPICap;
   
    //Coil 2 On 
    bufferCommandTwo[0] = C1R;
    bufferCommandTwo[1] = SPICap;
    
    //Driver Off
    bufferOff[0] = driverOff;
    bufferOff[1] = SPICap;
    
    IO_RA4_SetLow();
    
    SPI1_BufferWrite(bufferOff, 2);
    SPI1_ByteWrite(dummy);
    
    IO_RA4_SetHigh();
    
    __delay_ms(1);
    
    SPI1_BufferRead(bufferMessage, 2);
    //printf("AZNES1YB");
  
    while(1){
        if(msg_complete == 1){ //Eventually send to message compliance, temp to see if working
            //printf("Message: ");
            //printf("%s",msg);
            msg_complete = 0;
            //IO_RA3_SetLow();
            messageCompliance();
        }
        
        
    }
        
        
}